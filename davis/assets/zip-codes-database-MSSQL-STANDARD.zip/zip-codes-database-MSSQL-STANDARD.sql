/*
------------------------------------------------------------------
Provider:  Zip-Codes.com
Product:   U.S. ZIP Code Database Standard
------------------------------------------------------------------
This SQL Creates a new table named ZIPCodes, 
related indexes, and extended column information.

This script is designed to work with MS SQL Server 2000 & 2005

Actions:
  1.) Drop Table ZIPCodes if it exists
  2.) Creates Table named ZIPCodes
  3.) Creates Indexes on table ZIPCodes
  4.) Creates Extended Column Information

Last Updated: 12/21/2007
------------------------------------------------------------------
*/


/* 1.) Drop Table if it Exists */
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ZIPCodes]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ZIPCodes]
GO


/* 2.) Create Table */
CREATE TABLE [dbo].[ZIPCodes] (
	[ZipCode] [char] (5) NOT NULL,
	[City] [varchar] (35) NULL,
	[State] [char] (2),
	[County] [varchar] (45) NULL,
	[AreaCode] [varchar] (55) NULL,
	[CityType] [char] (1) NULL,
	[CityAliasAbbreviation] [varchar] (13) NULL,
	[CityAliasName] [varchar] (35) NULL,
	[Latitude] [decimal](12, 6),
	[Longitude] [decimal](12, 6),
	[TimeZone] [char] (2) NULL,
	[Elevation] [int],
	[CountyFIPS] [char] (5) NULL,
	[DayLightSaving] [char] (1) NULL,
	[PreferredLastLineKey] [varchar] (10) NULL,
	[ClassificationCode] [char] (1) NULL,
	[MultiCounty] [char] (1) NULL,
	[StateFIPS] [char] (2) NULL,
	[CityStateKey] [char] (6) NULL,
	[CityAliasCode] [varchar] (5) NULL,
	[PrimaryRecord] [char] (1),
	[CityMixedCase] [varchar] (35) NULL,
	[CityAliasMixedCase] [varchar] (35) NULL,
	[StateANSI] [varchar] (2) NULL,
	[CountyANSI] [varchar] (3) NULL,
	[FacilityCode] [varchar] (1) NULL,
	[CityDeliveryIndicator] [varchar] (1) NULL,
	[CarrierRouteRateSortation] [varchar] (1) NULL,
	[FinanceNumber] [varchar] (6) NULL,
	[UniqueZIPName] [varchar] (1) NULL,
	[CountyMixedCase] [varchar] (45) NULL
) ON [PRIMARY]
GO


/* 3.) Create Indexes on most searched fields */
CREATE  INDEX [Index_ZIPCodes_ZipCode]				 ON [dbo].[ZIPCodes]([ZipCode]) ON [PRIMARY]
CREATE  INDEX [Index_ZIPCodes_State]				 ON [dbo].[ZIPCodes]([State]) ON [PRIMARY]
CREATE  INDEX [Index_ZIPCodes_County]				 ON [dbo].[ZIPCodes]([County]) ON [PRIMARY]
CREATE  INDEX [Index_ZIPCodes_AreaCode]				 ON [dbo].[ZIPCodes]([AreaCode]) ON [PRIMARY]
CREATE  INDEX [Index_ZIPCodes_City]					 ON [dbo].[ZIPCodes]([City]) ON [PRIMARY]
CREATE  INDEX [Index_ZIPCodes_Latitude]				 ON [dbo].[ZIPCodes]([Latitude]) ON [PRIMARY]
CREATE  INDEX [Index_ZIPCodes_Longitude]			 ON [dbo].[ZIPCodes]([Longitude]) ON [PRIMARY]
CREATE  INDEX [Index_ZIPCodes_CityAliasName]		 ON [dbo].[ZIPCodes]([CityAliasName]) ON [PRIMARY]
CREATE  INDEX [Index_ZIPCodes_CityStateKey]			 ON [dbo].[ZIPCodes]([CityStateKey]) ON [PRIMARY]
CREATE  INDEX [Index_ZIPCodes_PrimaryRecord]		 ON [dbo].[ZIPCodes]([PrimaryRecord]) ON [PRIMARY]
GO


/* 4.) Create Extended Column Information */
exec sp_addextendedproperty N'MS_Description', N'U.S. Zip Code Database Standard (from www.zip-codes.com)', N'user', N'dbo', N'table', N'ZIPCodes'
exec sp_addextendedproperty N'MS_Description', N'00000-99999 Five digit numeric ZIP Code of the area.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'ZipCode'
exec sp_addextendedproperty N'MS_Description', N'Geographic coordinate as a point measured in degrees north or south of the equator.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'Latitude'
exec sp_addextendedproperty N'MS_Description', N'Geographic coordinate as a point measured in degrees east or west of the Greenwich Meridian.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'Longitude'
exec sp_addextendedproperty N'MS_Description', N'The average elevation of the county.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'Elevation'
exec sp_addextendedproperty N'MS_Description', N'2 letter state name abbreviation.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'State'
exec sp_addextendedproperty N'MS_Description', N'Indicates the type of locale such as Post Office, Stations, or Branch.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'CityType'
exec sp_addextendedproperty N'MS_Description', N'13 Character abbreviation for the city alias name.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'CityAliasAbbreviation'
exec sp_addextendedproperty N'MS_Description', N'The telephone area codes available in this ZIP Code.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'AreaCode'
exec sp_addextendedproperty N'MS_Description', N'Name of the city as designated by the USPS.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'City'
exec sp_addextendedproperty N'MS_Description', N'Alias name of the city if it exists.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'CityAliasName'
exec sp_addextendedproperty N'MS_Description', N'Name of County or Parish this ZIP Code resides in.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'County'
exec sp_addextendedproperty N'MS_Description', N'FIPS code for the County/Parish this ZIP Code resides in.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'CountyFIPS'
exec sp_addextendedproperty N'MS_Description', N'FIPS code for the State this ZIP Code resides in.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'StateFIPS'
exec sp_addextendedproperty N'MS_Description', N'Hours past Greenwich Time Zone this ZIP Code belongs to.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'TimeZone'
exec sp_addextendedproperty N'MS_Description', N'Flag indicating whether this ZIP Code observes daylight savings.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'DayLightSaving'
exec sp_addextendedproperty N'MS_Description', N'Links this record with other products ZIP-Codes.com offers', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'PreferredLastLineKey'
exec sp_addextendedproperty N'MS_Description', N'The classification type of this ZIP Code.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'ClassificationCode'
exec sp_addextendedproperty N'MS_Description', N'Flag indicating whether this ZIP Code crosses county lines.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'MultiCounty'
exec sp_addextendedproperty N'MS_Description', N'Links this record with other products ZIP-Codes.com offers such as the ZIP+4.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'CityStateKey'
exec sp_addextendedproperty N'MS_Description', N'Code indicating the type of the city alias name for this record. Record can be Abbreviations, Universities, Government, and more.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'CityAliasCode'
exec sp_addextendedproperty N'MS_Description', N'Character �P� denoting if this row is a Primary Record or not. Absence of character denotes a non-primary record.', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'PrimaryRecord'
exec sp_addextendedproperty N'MS_Description', N'The city name in mixed case (i.e. Not in all uppercase letters).', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'CityMixedCase'
exec sp_addextendedproperty N'MS_Description', N'The city alias name in mixed case (i.e. Not in all uppercase letters).', N'user', N'dbo', N'table', N'ZIPCodes', N'column', N'CityAliasMixedCase'
GO

